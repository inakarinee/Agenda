function cadastro (){
    var usuario = document.getElementById("nome").value;
    var senha = document.getElementById("senha").value;
    var matricula = document.getElementById("matricula").value;
    var email = document.getElementById("email").value;
    var area = document.getElementById("area").value;
    var cargahoraria = document.getElementById("cargahoraria").value;

}

